使用方式：在 make.cpp 中写好 generator，function//std//std.cpp 中写好 std，运行即可。



以下是该数据生成器定义的：

```c++
//file.h
writein(s,n)              //打开输入文件，s为文件名，n为编号
writeout(s,n)             //打开输出文件，s为文件名，n为编号
//random.h
Rand(l,r)                 //生成一个[l,r]中的随机整数。
Rand(l,r,d)               //生成一个[l,r]中的随机浮点数，保留到小数点后d位
RandBool()                //生成一个[0,1]之间的随机整数。
RandReal(d)               //生成一个保留d位小数的随机浮点数。
RandChar(l,r)             //生成一个ASCLL码在[l,r]的随机字符
//point.h
Point<type>point;         //定义一个点
point(x,y);               //初始化point
O                         //原点
```

