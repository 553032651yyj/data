#include "data.h"
#include<bits/stdc++.h>
using namespace std;
int main(){
	writein("data",3);
	cout<<10;
	writeout("data",3);
} 
