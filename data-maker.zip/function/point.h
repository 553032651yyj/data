#include<bits/stdc++.h>
using namespace std;
template<typename T>struct Point{
    T x,y;
    Point(T x=0,T y=0) : x(x),y(y) {}
};
#define O Point<int> O(0,0)
void RandPoint(){
	
}
