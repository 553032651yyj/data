#include<bits/stdc++.h>
using namespace std;

inline int MTrand() {
    struct MTrand{
        bool Init;
        int MTindex;
        long long MT[624];
    };
	static MTrand mt;
	if(!mt.Init){
		mt.Init=true;
    	mt.MTindex=0;
     	mt.MT[0]=int(time(NULL));
    	for(int i=1;i<624;i++) {
     		int t=1812433253*(mt.MT[i-1]^(mt.MT[i-1]>>30))+i;
	    	mt.MT[i]=t&0xffffffff;
     	}
	}
	if(mt.MTindex==0){
	    for(int i=0;i<624;i++) {
	    	long long y=(mt.MT[i]&0x80000000)+(mt.MT[(i+1)%624]&0x7fffffff);
	    	mt.MT[i]=mt.MT[(i+397)%624]^(y>>1);
	    	if(y%2==1) mt.MT[i]^=2147483647;
    	}
    }
	int y=mt.MT[mt.MTindex];
	y^=(y>>11);y^=((y<<7)&1636928640);y^=((y<<15)&1022730752);y^=(y>>18);
	mt.MTindex=(mt.MTindex+1)%624;
	return y;
}
long long Rand(int a,int b) {
	if(a>b) swap(a,b);
	if(a==b) return a;
	return MTrand()%(b-a+1)+a;
}
double Rand(int a,int b,int digit){
	if(a>b) swap(a,b);
	if(a==b) return a;
	return Rand(a,b-1)+Rand(1,pow(10,digit))*1.0/pow(10,digit);
}
bool RandBool(){
	return Rand(0,1);
}
double RandReal(int digit){
	return Rand(0,1,digit);
}
char RandChar(char l,char r){
	return char(Rand(int(l),int(r)));
}
