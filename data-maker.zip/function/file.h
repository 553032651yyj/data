#include<bits/stdc++.h>
using namespace std;
string turn(int x){
	string s;
	while(x){
		s=char((x%10)+'0')+s;
		x/=10;
	}
	return s;
}
inline void writein(string name,int n) {
	freopen("CON","r",stdin);
	freopen("CON","w",stdout);
	string openname="files\\"+name+turn(n)+".in";
	freopen(openname.c_str(),"w",stdout);
}
inline void writeout(string name,int n) { 
	freopen("CON","r",stdin);
	freopen("CON","w",stdout); 
	string openname="files\\"+name+turn(n)+".in";
	freopen(openname.c_str(),"r",stdin);
	openname="files\\"+name+turn(n)+".out";
	freopen(openname.c_str(),"w",stdout);
	system("function\\std\\std.exe");
} 
