#include<bits/stdc++.h>
#include "function/random.h"
#include "function/file.h"
#include "function/point.h" 
using namespace std; 
